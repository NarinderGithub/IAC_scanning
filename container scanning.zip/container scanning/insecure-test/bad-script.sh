#!/bin/bash

whoami
